// Init Locomotive Scroll
const scroll = new LocomotiveScroll({
  el: document.querySelector('#app'),
  smooth: true
});

const dataURL = 'https://raw.githubusercontent.com/owid/covid-19-data/master/public/data/vaccinations/vaccinations.json';

let chart;
let chartData = [];
let currentChartType = 'bar';

// Fetch vaccine data
async function fetchData() {
  const res = await fetch(dataURL);
  const raw = await res.json();

  chartData = raw
    .map(d => {
      const last = d.data[d.data.length - 1];
      return {
        country: d.country,
        people_vaccinated: last.people_vaccinated || 0,
        total_vaccinations: last.total_vaccinations || 0,
        date: last.date
      };
    })
    .filter(d => d.total_vaccinations > 50000000)
    .sort((a, b) => b.total_vaccinations - a.total_vaccinations);

  drawChart();
}

// Draw chart
function drawChart() {
  const ctx = document.getElementById('wellbeingChart').getContext('2d');
  if (chart) chart.destroy();

  chart = new Chart(ctx, {
    type: currentChartType,
    data: {
      labels: chartData.map(d => d.country),
      datasets: [{
        label: 'Total Vaccinations',
        data: chartData.map(d => d.total_vaccinations),
        backgroundColor: 'rgba(100, 200, 255, 0.7)',
        borderColor: 'rgba(50, 150, 255, 1)',
        borderWidth: 1,
        hoverBorderWidth: 3,
        hoverBackgroundColor: 'rgba(255, 99, 132, 0.7)',
      }]
    },
    options: {
      animation: {
        duration: 2000,
        easing: 'easeOutElastic'
      },
      responsive: true,
      plugins: {
        tooltip: {
          callbacks: {
            label: ctx => {
              const d = chartData[ctx.dataIndex];
              return [
                `Vaccinated: ${d.people_vaccinated?.toLocaleString()}`,
                `Total: ${d.total_vaccinations.toLocaleString()}`,
                `Date: ${d.date}`
              ];
            }
          }
        }
      }
    }
  });
}

// Search filter
document.getElementById('countrySearch').addEventListener('input', _.debounce((e) => {
  const val = e.target.value.toLowerCase();
  const filtered = chartData.filter(d => d.country.toLowerCase().includes(val));
  if (filtered.length > 0) {
    chart.data.labels = filtered.map(d => d.country);
    chart.data.datasets[0].data = filtered.map(d => d.total_vaccinations);
    chart.update();
  }
}, 300));

// Chart type switch
document.getElementById('chartType').addEventListener('change', (e) => {
  currentChartType = e.target.value;
  drawChart();
});

// Init fetch
fetchData();
